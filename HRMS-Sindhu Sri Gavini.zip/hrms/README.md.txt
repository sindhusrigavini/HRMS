# HRMS Django Application

This is a simple Human Resource Management System (HRMS) built using Django.
It supports employee management, attendance tracking, and basic reporting.

---

## Project Structure

hrms/
│── employees/
│   ├── models.py        # Employee & Attendance models
│   ├── views.py         # Views and APIs
│   ├── urls.py          # App URLs
│
│── hrms/
│   ├── settings.py
│   ├── urls.py
│
│── static/
│   ├── home.css         # Frontend styling
│
│── templates/
│   ├── home.html
│   ├── employee_list.html
│   ├── report.html
│
│── manage.py
│── venv/


---

## Features

- Employee Management
- Attendance Tracking (In Time / Out Time)
- Department-wise Employee Report
- Django Admin Panel

---

## How to Run the Project Locally

Follow the steps below **in order**.

---

### 1️⃣ Create Virtual Environment
```bash

python -m venv venv

2️⃣ Activate Virtual Environment (Windows)

venv\Scripts\activate


You should see (venv) in the terminal.

3️⃣ Install Django
pip install django


Verify installation:

python -m django --version

4️⃣ Apply Database Migrations
python manage.py makemigrations
python manage.py migrate

5️⃣ Create Superuser (Admin)
python manage.py createsuperuser


Enter the details when prompted:

Username: admin
Email address: admin@example.com
Password:
Password (again):

(Note: Password will not be visible while typing.)

My username:sindhusrigavini
Password:Sindhu@30

6️⃣ Run the Development Server
python manage.py runserver