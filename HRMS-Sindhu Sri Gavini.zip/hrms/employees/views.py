from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Count
from .models import Employee, Attendance
import json


def home(request):
    return render(request, "home.html")

def employee_list(request):
    """Display all employees"""
    employees = Employee.objects.all()
    return render(request, "employee_list.html", {"employees": employees})


def department_report(request):
    """Department-wise employee count"""
    report = Employee.objects.values("department").annotate(total=Count("id"))
    return render(request, "report.html", {"report": report})


def employee_detail(request, emp_id):
    """Employee details with attendance"""
    employee = Employee.objects.get(id=emp_id)
    attendance = Attendance.objects.filter(employee=employee)
    return render(
        request,
        "employee_detail.html",
        {"employee": employee, "attendance": attendance},
    )


@csrf_exempt
def add_employee_api(request):
    """API to add employee"""
    if request.method == "POST":
        data = json.loads(request.body)
        Employee.objects.create(
            name=data.get("name"),
            designation=data.get("designation"),
            department=data.get("department"),
            email=data.get("email"),
            address=data.get("address"),
            date_of_joining=data.get("date_of_joining"),
        )
        return JsonResponse({"message": "Employee added successfully"})


def employee_list_api(request):
    """API to get employees"""
    employees = list(Employee.objects.values())
    return JsonResponse(employees, safe=False)


@csrf_exempt
def mark_attendance_api(request):
    """API to mark attendance"""
    if request.method == "POST":
        data = json.loads(request.body)
        Attendance.objects.create(
            employee_id=data.get("employee_id"),
            date=data.get("date"),
            in_time=data.get("in_time"),
            out_time=data.get("out_time"),
        )
        return JsonResponse({"message": "Attendance marked successfully"})


def attendance_list_api(request, emp_id):
    """API to get attendance"""
    attendance = list(
        Attendance.objects.filter(employee_id=emp_id).values()
    )
    return JsonResponse(attendance, safe=False)
