from django.urls import path
from . import views

urlpatterns = [
    path("", views.employee_list),
    path("report/", views.department_report),
    path("employee/<int:emp_id>/", views.employee_detail),

    # APIs
    path("api/add-employee/", views.add_employee_api),
    path("api/employees/", views.employee_list_api),
    path("api/mark-attendance/", views.mark_attendance_api),
    path("api/attendance/<int:emp_id>/", views.attendance_list_api),
]
